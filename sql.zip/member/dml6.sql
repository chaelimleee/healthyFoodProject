-- 관리자(admin : abcd1234) 계정 선정
-- 회원 정보 롤(등급) 생성
INSERT INTO user_roles VALUES (
user_roles_seq.nextval,
'abcd1234',
'ROLE_ADMIN'
);

